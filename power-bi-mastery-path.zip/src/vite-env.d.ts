declare const process: {
  env: {
    API_KEY: string;
  };
};
